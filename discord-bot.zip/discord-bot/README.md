# Mega Discord Bot (240 commands)
1. npm install
2. cp .env.example .env  -> put your TOKEN
3. Discord Developer Portal > Bot: enable SERVER MEMBERS + MESSAGE CONTENT intents
4. npm start
Use !help to see all categories. Default prefix: !
