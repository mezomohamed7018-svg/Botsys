const db=require('../db');const S=require('../systems');
module.exports={name:'guildMemberRemove',run(c,m){const g=m.guild.id;
 const ch=c.channels.cache.get(db.get(`leave:${g}`));if(ch)ch.send(S.fillMsg(db.get(`leavemsg:${g}`,'😢 **{name}** left {server}.'),m));
 S.log(c,g,`📤 ${m.user.tag} left`)}};
