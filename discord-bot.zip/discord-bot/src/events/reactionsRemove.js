const db=require('../db');
module.exports={name:'messageReactionRemove',async run(c,r,u){if(u.bot)return;if(r.partial)await r.fetch().catch(()=>{});const g=r.message.guild;if(!g)return;const role=db.get(`rr:${g.id}:${r.message.id}:${r.emoji.id||r.emoji.name}`);if(role)(await g.members.fetch(u.id).catch(()=>null))?.roles.remove(role).catch(()=>{})}};
