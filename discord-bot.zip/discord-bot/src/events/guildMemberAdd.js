const db=require('../db');const S=require('../systems');
module.exports={name:'guildMemberAdd',run(c,m){const g=m.guild.id;
 const ar=db.get(`autorole:${g}`);if(ar)m.roles.add(ar).catch(()=>{});
 const ch=c.channels.cache.get(db.get(`welcome:${g}`));if(ch)ch.send(S.fillMsg(db.get(`welcomemsg:${g}`,'👋 Welcome {user} to **{server}**! You are member #{count}'),m));
 S.log(c,g,`📥 ${m.user.tag} joined`)}};
