const db=require('../db');
const key=r=>r.emoji.id||r.emoji.name;
const rr=async(c,r,u,add)=>{if(u.bot)return;if(r.partial)await r.fetch().catch(()=>{});const g=r.message.guild;if(!g)return;
 const role=db.get(`rr:${g.id}:${r.message.id}:${key(r)}`);if(role){const m=await g.members.fetch(u.id).catch(()=>null);if(m)add?m.roles.add(role).catch(()=>{}):m.roles.remove(role).catch(()=>{})}
 if(add&&r.emoji.name==='⭐'&&r.count>=3){const ch=c.channels.cache.get(db.get(`starch:${g.id}`));const k=`starred:${r.message.id}`;if(ch&&!db.get(k)){db.set(k,1);const msg=r.message.partial?await r.message.fetch():r.message;ch.send(`⭐ **${r.count}** | ${msg.author} in ${msg.channel}\n${msg.content||''}\n${msg.url}`)}}};
module.exports=[{name:'messageReactionAdd',run:(c,r,u)=>rr(c,r,u,true)}][0];
