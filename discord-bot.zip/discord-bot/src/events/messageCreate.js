const {PermissionFlagsBits:P}=require('discord.js');const db=require('../db');
module.exports={name:'messageCreate',async run(c,m){
 if(m.author.bot||!m.guild)return;
 await require('../systems').onMessage(c,m);
 const prefix=db.get(`prefix:${m.guild.id}`,process.env.PREFIX||'!');
 if(!m.content.startsWith(prefix))return;
 const a=m.content.slice(prefix.length).trim().split(/\s+/),n=a.shift().toLowerCase();
 const cmd=c.commands.get(n)||c.commands.get(c.aliases.get(n));
 if(!cmd){const cc=db.get(`cc:${m.guild.id}:${n}`);if(cc)m.reply(cc);return}
 if(cmd.perm&&!m.member.permissions.has(P[cmd.perm]))return m.reply(`❌ Missing permission: ${cmd.perm}`);
 if(cmd.args&&a.length<cmd.args)return m.reply(`Usage: \`${prefix}${cmd.name} ${cmd.usage||''}\``);
 try{await cmd.run(m,a,c)}catch(e){console.error(e);m.reply('⚠️ '+String(e.message).slice(0,200))}
}};
