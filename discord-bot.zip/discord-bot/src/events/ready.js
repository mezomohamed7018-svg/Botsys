module.exports={name:'clientReady',run(c){console.log(`✅ ${c.user.tag} online in ${c.guilds.cache.size} servers`);c.user.setActivity('!help');require('../systems').tick(c)}};
