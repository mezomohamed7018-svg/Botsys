const db=require('./db');const {del}=require('./util');
const S=exports;const spam=new Map(),xpcd=new Map();
S.lvl=xp=>Math.floor(Math.sqrt(xp/100));
S.log=(c,g,text)=>{const id=db.get(`logch:${g}`);const ch=id&&c.channels.cache.get(id);if(ch)ch.send({content:text.slice(0,1900),allowedMentions:{parse:[]}}).catch(()=>{})};
S.fillMsg=(t,m)=>t.replace(/{user}/g,`<@${m.id}>`).replace(/{name}/g,m.user.username).replace(/{server}/g,m.guild.name).replace(/{count}/g,m.guild.memberCount);
S.onMessage=async(c,m)=>{
 const g=m.guild.id,u=m.author.id;
 if(db.get(`afk:${g}:${u}`)){db.del(`afk:${g}:${u}`);m.reply('👋 Welcome back, AFK removed.').then(x=>del(x))}
 m.mentions.users.forEach(x=>{const r=db.get(`afk:${g}:${x.id}`);if(r)m.reply({content:`💤 **${x.username}** is AFK: ${r}`,allowedMentions:{parse:[]}})});
 if(!m.member.permissions.has('ManageMessages')){
  const kill=async why=>{await m.delete().catch(()=>{});m.channel.send(`${m.author}, ${why}`).then(x=>del(x,4000));return true};
  if(db.get(`am:link:${g}`)&&/(https?:\/\/|discord\.gg\/)/i.test(m.content))return kill('links are not allowed.');
  const bw=db.get(`badwords:${g}`,[]);if(bw.some(w=>m.content.toLowerCase().includes(w)))return kill('watch your language.');
  if(db.get(`am:caps:${g}`)&&m.content.length>10&&m.content.replace(/[^A-Z]/g,'').length/m.content.length>.7)return kill('too many capital letters.');
  if(db.get(`am:mention:${g}`)&&m.mentions.users.size>=5)return kill('mass mentions are not allowed.');
  if(db.get(`am:spam:${g}`)){const k=g+u,t=(spam.get(k)||[]).filter(x=>Date.now()-x<5000);t.push(Date.now());spam.set(k,t);if(t.length>=6){m.member.timeout(60000,'Spam').catch(()=>{});m.channel.send(`🔇 ${m.author} muted 1m for spam.`)}}
 }
 const cnt=db.get(`count:${g}`);
 if(cnt&&cnt.ch===m.channel.id){const n=parseInt(m.content);if(n===cnt.n+1&&u!==cnt.last){db.set(`count:${g}`,{...cnt,n,last:u});m.react('✅')}else if(!isNaN(n)||true){db.set(`count:${g}`,{...cnt,n:0,last:null});m.react('❌');m.channel.send(`💥 ${m.author} ruined it! Back to 1.`)}}
 if(!db.get(`lvloff:${g}`)){
  const k=g+u;if(Date.now()-(xpcd.get(k)||0)>60000){xpcd.set(k,Date.now());
   const key=`xp:${g}:${u}`,before=S.lvl(db.get(key,0)),xp=db.add(key,Math.floor(Math.random()*11)+15),after=S.lvl(xp);
   if(after>before){m.channel.send(`🎉 ${m.author} reached level **${after}**!`);const r=db.get(`lvlroles:${g}`,{})[after];if(r)m.member.roles.add(r).catch(()=>{})}}
 }
};
S.endGiveaway=async(c,gw)=>{
 const ch=c.channels.cache.get(gw.ch);if(!ch)return;const msg=await ch.messages.fetch(gw.msg).catch(()=>null);if(!msg)return;
 const r=msg.reactions.cache.get('🎉');const us=r?(await r.users.fetch()).filter(x=>!x.bot).map(x=>x):[];
 const win=us.sort(()=>Math.random()-.5).slice(0,gw.w);
 ch.send(win.length?`🎉 Congratulations ${win.join(', ')}! You won **${gw.prize}**`:'😢 No valid entries.');
 msg.edit({content:'🎉 **GIVEAWAY ENDED**'}).catch(()=>{});
};
S.tick=c=>setInterval(async()=>{
 const now=Date.now();
 const temp=db.get('temp',[]);if(temp.some(x=>x.at<=now)){for(const x of temp.filter(x=>x.at<=now))c.guilds.cache.get(x.g)?.members.unban(x.u).catch(()=>{});db.set('temp',temp.filter(x=>x.at>now))}
 const rem=db.get('reminders',[]);if(rem.some(x=>x.at<=now)){for(const x of rem.filter(x=>x.at<=now))c.channels.cache.get(x.ch)?.send(`⏰ <@${x.u}> reminder: ${x.text}`).catch(()=>{});db.set('reminders',rem.filter(x=>x.at>now))}
 const gws=db.get('giveaways',[]);if(gws.some(x=>x.end<=now)){for(const x of gws.filter(x=>x.end<=now))S.endGiveaway(c,x);db.set('giveaways',gws.filter(x=>x.end>now))}
 const d=new Date(),day=d.toISOString().slice(5,10),today=d.toISOString().slice(0,10);
 if(d.getUTCHours()>=6&&db.get('bdaylast')!==today){db.set('bdaylast',today);for(const [k,v] of db.all('bday:')){if(v!==day)continue;const [,g,u]=k.split(':');const ch=c.channels.cache.get(db.get(`bdaych:${g}`));ch?.send(`🎂 Happy birthday <@${u}>! 🎉`)}}
},20000);
