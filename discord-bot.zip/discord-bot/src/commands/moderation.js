const {cmd,member,id,dur,role}=require('../util');const db=require('../db');
const C='Moderation',R=a=>a.join(' ')||'No reason provided';
const need=async(m,a)=>{const t=await member(m,a[0]);if(!t)throw new Error('Member not found');return t};
const P=(perm,usage)=>({perm,args:1,usage});
const setPerm=(m,v)=>m.channel.permissionOverwrites.edit(m.guild.id,v);
const lockAll=async(m,v)=>{for(const [,c] of m.guild.channels.cache.filter(c=>c.isTextBased()&&!c.isThread()&&!c.isVoiceBased()))await c.permissionOverwrites.edit(m.guild.id,{SendMessages:v}).catch(()=>{})};
module.exports=[
cmd('ban',C,'Ban a user',async(m,a)=>{const u=await m.client.users.fetch(id(a[0]));await m.guild.members.ban(u,{reason:R(a.slice(1))});m.reply(`🔨 Banned **${u.tag}**`)},P('BanMembers','<user> [reason]')),
cmd('unban',C,'Unban a user',async(m,a)=>{await m.guild.members.unban(id(a[0]));m.reply('✅ Unbanned')},P('BanMembers','<userId>')),
cmd('kick',C,'Kick a member',async(m,a)=>{const t=await need(m,a);await t.kick(R(a.slice(1)));m.reply(`👢 Kicked **${t.user.tag}**`)},P('KickMembers','<user> [reason]')),
cmd('mute',C,'Timeout a member',async(m,a)=>{const t=await need(m,a);await t.timeout(dur(a[1])||6e5,R(a.slice(2)));m.reply(`🔇 Muted **${t.user.tag}**`)},{...P('ModerateMembers','<user> [10m] [reason]'),aliases:['timeout']}),
cmd('unmute',C,'Remove timeout',async(m,a)=>{const t=await need(m,a);await t.timeout(null);m.reply('🔊 Unmuted')},P('ModerateMembers','<user>')),
cmd('warn',C,'Warn a member',async(m,a)=>{const t=await need(m,a);db.push(`warns:${m.guild.id}:${t.id}`,{r:R(a.slice(1)),by:m.author.tag,at:Date.now()});m.reply(`⚠️ Warned **${t.user.tag}**`)},P('ModerateMembers','<user> [reason]')),
cmd('warnings',C,'Show warnings',async(m,a)=>{const t=await need(m,a);const w=db.get(`warns:${m.guild.id}:${t.id}`,[]);m.reply(w.length?w.map((x,i)=>`${i+1}. ${x.r} — ${x.by}`).join('\n'):'No warnings')},{...P('ModerateMembers','<user>'),aliases:['warns']}),
cmd('clearwarns',C,'Clear warnings',async(m,a)=>{const t=await need(m,a);db.del(`warns:${m.guild.id}:${t.id}`);m.reply('🧹 Cleared')},P('ModerateMembers','<user>')),
cmd('purge',C,'Delete messages',async(m,a)=>{const n=Math.min(parseInt(a[0])||10,99);const r=await m.channel.bulkDelete(n+1,true);m.channel.send(`🧹 Deleted ${r.size-1}`).then(x=>setTimeout(()=>x.delete().catch(()=>{}),3000))},{...P('ManageMessages','<1-99>'),aliases:['clear','prune']}),
cmd('purgebots',C,'Delete bot messages',async(m)=>{const f=(await m.channel.messages.fetch({limit:100})).filter(x=>x.author.bot);await m.channel.bulkDelete(f,true);m.channel.send(`🧹 ${f.size}`)},{perm:'ManageMessages'}),
cmd('purgeuser',C,'Delete a user\'s messages',async(m,a)=>{const f=(await m.channel.messages.fetch({limit:100})).filter(x=>x.author.id===id(a[0]));await m.channel.bulkDelete(f,true);m.channel.send(`🧹 ${f.size}`)},P('ManageMessages','<user>')),
cmd('slowmode',C,'Set slowmode (seconds)',async(m,a)=>{await m.channel.setRateLimitPerUser(parseInt(a[0])||0);m.reply('🐌 Done')},{...P('ManageChannels','<seconds>'),aliases:['slow']}),
cmd('lock',C,'Lock channel',async m=>{await setPerm(m,{SendMessages:false});m.reply('🔒 Locked')},{perm:'ManageChannels'}),
cmd('unlock',C,'Unlock channel',async m=>{await setPerm(m,{SendMessages:null});m.reply('🔓 Unlocked')},{perm:'ManageChannels'}),
cmd('lockdown',C,'Lock all channels',async m=>{await lockAll(m,false);m.reply('🚨 Server locked')},{perm:'Administrator'}),
cmd('unlockdown',C,'Unlock all channels',async m=>{await lockAll(m,null);m.reply('✅ Server unlocked')},{perm:'Administrator'}),
cmd('hide',C,'Hide channel',async m=>{await setPerm(m,{ViewChannel:false});m.reply('🙈 Hidden')},{perm:'ManageChannels'}),
cmd('unhide',C,'Unhide channel',async m=>{await setPerm(m,{ViewChannel:null});m.reply('👁️ Visible')},{perm:'ManageChannels'}),
cmd('nick',C,'Change nickname',async(m,a)=>{const t=await need(m,a);await t.setNickname(a.slice(1).join(' ')||null);m.reply('✏️ Done')},P('ManageNicknames','<user> <name>')),
cmd('softban',C,'Ban+unban to purge messages',async(m,a)=>{const t=await need(m,a);await t.ban({deleteMessageSeconds:86400});await m.guild.members.unban(t.id);m.reply('🧽 Softbanned')},P('BanMembers','<user>')),
cmd('tempban',C,'Temporary ban',async(m,a)=>{const t=await need(m,a);const ms=dur(a[1]);if(!ms)throw new Error('Use time like 1d');await t.ban({reason:R(a.slice(2))});db.push('temp',{type:'unban',g:m.guild.id,u:t.id,at:Date.now()+ms});m.reply(`⏳ Tempbanned ${a[1]}`)},P('BanMembers','<user> <1d> [reason]')),
cmd('addrole',C,'Give role',async(m,a)=>{const t=await need(m,a),r=role(m,a[1]);if(!r)throw new Error('Role not found');await t.roles.add(r);m.reply('✅ Added')},{...P('ManageRoles','<user> <role>'),aliases:['giverole']}),
cmd('removerole',C,'Remove role',async(m,a)=>{const t=await need(m,a),r=role(m,a[1]);if(!r)throw new Error('Role not found');await t.roles.remove(r);m.reply('✅ Removed')},{...P('ManageRoles','<user> <role>'),aliases:['takerole']}),
cmd('vckick',C,'Disconnect from voice',async(m,a)=>{const t=await need(m,a);await t.voice.disconnect();m.reply('👢 Done')},P('MoveMembers','<user>')),
cmd('vcmute',C,'Server-mute in voice',async(m,a)=>{const t=await need(m,a);await t.voice.setMute(true);m.reply('🔇 Done')},P('MuteMembers','<user>')),
cmd('vcunmute',C,'Unmute in voice',async(m,a)=>{const t=await need(m,a);await t.voice.setMute(false);m.reply('🔊 Done')},P('MuteMembers','<user>')),
cmd('vcmove',C,'Move to voice channel',async(m,a)=>{const t=await need(m,a);await t.voice.setChannel(id(a[1]));m.reply('➡️ Done')},P('MoveMembers','<user> <channelId>')),
cmd('banlist',C,'List bans',async m=>{const b=await m.guild.bans.fetch();m.reply(b.size?b.map(x=>x.user.tag).slice(0,40).join('\n'):'No bans')},{perm:'BanMembers'}),
cmd('note',C,'Add mod note',async(m,a)=>{const t=await need(m,a);db.push(`notes:${m.guild.id}:${t.id}`,a.slice(1).join(' '));m.reply('📝 Saved')},P('ModerateMembers','<user> <text>')),
cmd('notes',C,'View mod notes',async(m,a)=>{const t=await need(m,a);const n=db.get(`notes:${m.guild.id}:${t.id}`,[]);m.reply(n.length?n.map((x,i)=>`${i+1}. ${x}`).join('\n'):'No notes')},P('ModerateMembers','<user>')),
];
