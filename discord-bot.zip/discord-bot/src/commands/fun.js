const {cmd,emb,pick,rand,member,id}=require('../util');
const C='Fun';
const A={hug:['🤗','hugs'],slap:['👋','slaps'],kiss:['😘','kisses'],pat:['🫳','pats'],punch:['👊','punches'],cuddle:['🥰','cuddles'],poke:['👉','pokes'],bite:['😬','bites'],highfive:['🙌','high-fives'],tickle:['🤭','tickles'],wave:['👋','waves at'],bonk:['🔨','bonks'],boop:['👃','boops'],feed:['🍔','feeds'],cheer:['🎉','cheers for'],stare:['👀','stares at'],salute:['🫡','salutes'],throw:['🥎','throws a ball at'],nom:['😋','nom-noms'],tackle:['🏈','tackles']};
const acts=Object.entries(A).map(([n,[e,v]])=>cmd(n,C,`${n} someone`,m=>{const t=m.mentions.users.first();m.reply(`${e} **${m.author.username}** ${v} ${t?`**${t.username}**`:'themselves'}!`)}));
const S={dance:'💃 is dancing!',cry:'😭 is crying.',laugh:'😂 is laughing!',shrug:'🤷 shrugs.',blush:'😊 blushes.',sleep:'😴 fell asleep.',facepalm:'🤦 facepalms.',smile:'😄 smiles.',angry:'😡 is angry!',think:'🤔 is thinking...',sing:'🎤 is singing!',run:'🏃 runs away!',jump:'🦘 jumps!',flex:'💪 flexes!',yawn:'🥱 yawns.'};
const solos=Object.entries(S).map(([n,t])=>cmd(n,C,`Emote: ${n}`,m=>m.reply(`**${m.author.username}** ${t}`)));
const L=(n,d,arr,pre='')=>cmd(n,C,d,m=>m.reply(pre+pick(arr)));
const J=['Why do programmers prefer dark mode? Light attracts bugs.','I told my computer I needed a break. It froze.','There are 10 kinds of people: those who know binary and those who don\'t.','Debugging: being the detective in a crime movie where you are also the murderer.','A SQL query walks into a bar, sees two tables and asks: can I join you?'];
const F=['Honey never spoils.','Octopuses have three hearts.','Bananas are berries; strawberries are not.','A day on Venus is longer than its year.','Sharks existed before trees.','Wombat poop is cube-shaped.'];
const Q=['The best way to predict the future is to create it.','Do or do not. There is no try.','Stay hungry, stay foolish.','It always seems impossible until it is done.','Dream big, start small.'];
const TR=['What is your biggest fear?','What is your most embarrassing moment?','What is a secret talent you have?','Who was your first crush?','What is the weirdest thing you have eaten?'];
const DR=['Send a voice message singing.','Change your nickname to "Potato" for an hour.','Talk in emojis only for 5 minutes.','Compliment everyone in chat.','Post your most recent photo.'];
const W=['Be able to fly or be invisible?','Never use social media or never watch movies?','Always be 10 min late or 20 min early?','Lose all your money or all your memories?','Live without music or without TV?'];
const RO=['You\'re the human version of a loading screen.','Your WiFi has better connection than your jokes.','You have the energy of a phone at 1%.','Even Clippy wouldn\'t help you.'];
const CO=['You light up the server!','You are a legend.','Your vibe is unmatched.','You make this community better.','Your smile is contagious.'];
const FO=['Great fortune awaits you.','A surprise is coming soon.','Today is your lucky day.','Avoid risky decisions today.','Someone is thinking of you.'];
const B=['It is certain.','Without a doubt.','Yes definitely.','Ask again later.','Cannot predict now.','Don\'t count on it.','My sources say no.','Very doubtful.'];
const TRV=[['Capital of France?','paris'],['2+2*2=?','6'],['Largest planet?','jupiter'],['Chemical symbol for water?','h2o'],['How many continents?','7'],['Fastest land animal?','cheetah']];
const wait=async(m,q,ans,ms=20000)=>{const r=await m.channel.awaitMessages({filter:x=>ans(x.content.toLowerCase().trim()),max:1,time:ms});const w=r.first();m.channel.send(w?`🏆 ${w.author} got it!`:'⏰ Time is up!')};
const scr=w=>w.split('').sort(()=>Math.random()-.5).join('');
const WORDS=['discord','javascript','server','keyboard','channel','community','message','developer','awesome','gaming'];
module.exports=[...acts,...solos,
L('joke',"Random joke",J,'😂 '),L('fact','Random fact',F,'💡 '),L('quote','Random quote',Q,'💬 '),
L('truth','Truth question',TR,'🎭 '),L('dare','Dare',DR,'🎯 '),L('wyr','Would you rather',W,'🤔 '),
L('roast','Light roast',RO,'🔥 '),L('compliment','Compliment',CO,'💖 '),L('fortune','Fortune',FO,'🔮 '),
L('topic','Chat topic',TR.concat(W),'💭 '),
cmd('8ball',C,'Magic 8ball',m=>m.reply(`🎱 ${pick(B)}`),{args:1,usage:'<question>'}),
cmd('coinflip',C,'Flip a coin',m=>m.reply(Math.random()<.5?'🪙 Heads':'🪙 Tails'),{aliases:['flip','cf']}),
cmd('dice',C,'Roll d6',m=>m.reply(`🎲 ${rand(1,6)}`)),
cmd('roll',C,'Random number',(m,a)=>m.reply(`🎲 ${rand(parseInt(a[0])||1,parseInt(a[1])||100)}`),{usage:'[min] [max]'}),
cmd('rps',C,'Rock paper scissors',(m,a)=>{const o=['rock','paper','scissors'],u=(a[0]||'').toLowerCase(),b=pick(o);if(!o.includes(u))throw new Error('rock/paper/scissors');const w=u===b?'Draw!':(u==='rock'&&b==='scissors')||(u==='paper'&&b==='rock')||(u==='scissors'&&b==='paper')?'You win! 🎉':'I win! 😎';m.reply(`I chose **${b}**. ${w}`)},{args:1}),
cmd('rate',C,'Rate anything',(m,a)=>m.reply(`⭐ I rate **${a.join(' ')}** ${rand(0,10)}/10`),{args:1}),
cmd('ship',C,'Ship two users',(m,a)=>{const x=[...m.mentions.users.values()];if(x.length<2)throw new Error('Mention 2 users');m.reply(`💘 ${x[0].username} + ${x[1].username} = **${rand(0,100)}%**`)},{aliases:['love']}),
cmd('iq',C,'Random IQ',m=>m.reply(`🧠 IQ: ${rand(60,160)}`)),
cmd('choose',C,'Choose: a | b | c',(m,a)=>m.reply(`🤖 ${pick(a.join(' ').split('|'))}`),{args:1,usage:'a | b | c'}),
cmd('trivia',C,'Trivia question',async m=>{const [q,ans]=pick(TRV);await m.reply(`❓ ${q} (20s)`);await wait(m,q,x=>x===ans)}),
cmd('mathquiz',C,'Math race',async m=>{const x=rand(1,50),y=rand(1,50);await m.reply(`➕ ${x} + ${y} = ?`);await wait(m,'',s=>s===String(x+y),15000)}),
cmd('scramble',C,'Unscramble word',async m=>{const w=pick(WORDS);await m.reply(`🔤 Unscramble: **${scr(w)}**`);await wait(m,'',s=>s===w)}),
cmd('typerace',C,'Typing race',async m=>{const w=pick(WORDS)+' '+pick(WORDS);await m.reply(`⌨️ Type fast: \`${w}\``);await wait(m,'',s=>s===w,15000)}),
cmd('guess',C,'Guess number 1-10',async m=>{const n=rand(1,10);await m.reply('🔢 Guess 1-10!');await wait(m,'',s=>s===String(n),15000)}),
cmd('reaction',C,'Reaction speed test',async m=>{const s=await m.reply('Wait for it...');await new Promise(r=>setTimeout(r,rand(2000,5000)));await s.edit('👉 CLICK!');await s.react('⚡');const t=Date.now();const r=await s.awaitReactions({filter:(r,u)=>r.emoji.name==='⚡'&&!u.bot,max:1,time:10000});m.channel.send(r.size?`⚡ ${Date.now()-t}ms`:'Too slow')}),
cmd('slotsfun',C,'Free slots',m=>{const e=['🍒','🍋','🍇','💎','7️⃣'];const r=[pick(e),pick(e),pick(e)];m.reply(`${r.join(' | ')} ${r[0]===r[1]&&r[1]===r[2]?'🎉 JACKPOT':''}`)}),
cmd('pp',C,'Random size',m=>m.reply(`8${'='.repeat(rand(1,12))}D`)),
cmd('gayrate',C,'Random meter (just for fun)',m=>m.reply(`🌈 ${rand(0,100)}%`)),
cmd('hack',C,'Fake hack (joke)',async(m,a)=>{const s=await m.reply('💻 Hacking...');for(const t of['Finding IP...','Bypassing firewall...','Downloading memes...','Done! 😈'])await new Promise(r=>setTimeout(r,900)),await s.edit(`💻 ${t}`)}),
cmd('password',C,'Random password',m=>m.author.send(`🔑 ${Math.random().toString(36).slice(2,8)}${Math.random().toString(36).toUpperCase().slice(2,8)}!${rand(10,99)}`).then(()=>m.reply('📩 Sent in DM')).catch(()=>m.reply('Open your DMs'))),
cmd('color',C,'Random color',m=>{const c=rand(0,0xffffff);m.reply({embeds:[emb('🎨 #'+c.toString(16).padStart(6,'0'),'\u200b',c)]})}),
];
