const {cmd,emb,member,id,pick,rand,chan,role}=require('../util');const {version}=require('discord.js');
const C='Utility';
const fmt=ms=>{const s=Math.floor(ms/1e3);return `${Math.floor(s/86400)}d ${Math.floor(s%86400/3600)}h ${Math.floor(s%3600/60)}m ${s%60}s`};
const T=d=>`<t:${Math.floor(d/1e3)}:R>`;
const tgt=async m=>(await member(m,m.content.split(/\s+/)[1]))||m.member;
module.exports=[
cmd('ping',C,'Bot latency',m=>m.reply(`🏓 ${m.client.ws.ping}ms`)),
cmd('uptime',C,'Bot uptime',m=>m.reply(`⏱️ ${fmt(m.client.uptime)}`)),
cmd('help',C,'Show commands',(m,a,c)=>{const all=[...c.commands.values()],cats=[...new Set(all.map(x=>x.category))],q=(a[0]||'').toLowerCase();
const cat=cats.find(x=>x.toLowerCase()===q);
if(cat)return m.reply({embeds:[emb(`${cat} (${all.filter(x=>x.category===cat).length})`,all.filter(x=>x.category===cat).map(x=>`\`${x.name}\``).join(' '))]});
const one=c.commands.get(q);if(one)return m.reply({embeds:[emb(one.name,`${one.desc}\nUsage: \`${one.name} ${one.usage||''}\`${one.perm?`\nPerm: ${one.perm}`:''}`)]});
m.reply({embeds:[emb('📖 Help',`Total commands: **${all.length}**\nUse \`help <category>\` or \`help <command>\`\n\n`+cats.map(x=>`**${x}** — ${all.filter(y=>y.category===x).length}`).join('\n'))]})},{aliases:['h','commands']}),
cmd('avatar',C,'Show avatar',async m=>{const t=await tgt(m);m.reply(t.displayAvatarURL({size:1024}))},{aliases:['av']}),
cmd('banner',C,'Show banner',async m=>{const t=await tgt(m);const u=await t.user.fetch();m.reply(u.bannerURL({size:1024})||'No banner')}),
cmd('userinfo',C,'User info',async m=>{const t=await tgt(m);m.reply({embeds:[emb(t.user.tag,`ID: ${t.id}\nCreated: ${T(t.user.createdTimestamp)}\nJoined: ${T(t.joinedTimestamp)}\nRoles: ${t.roles.cache.size-1}`).setThumbnail(t.displayAvatarURL())]})},{aliases:['whois','ui']}),
cmd('serverinfo',C,'Server info',m=>{const g=m.guild;m.reply({embeds:[emb(g.name,`Owner: <@${g.ownerId}>\nMembers: ${g.memberCount}\nChannels: ${g.channels.cache.size}\nRoles: ${g.roles.cache.size}\nBoosts: ${g.premiumSubscriptionCount}\nCreated: ${T(g.createdTimestamp)}`).setThumbnail(g.iconURL())]})},{aliases:['si']}),
cmd('roleinfo',C,'Role info',(m,a)=>{const r=role(m,a[0]);if(!r)throw new Error('Role not found');m.reply({embeds:[emb(r.name,`ID: ${r.id}\nMembers: ${r.members.size}\nColor: ${r.hexColor}\nPosition: ${r.position}`,r.color)]})},{args:1,usage:'<role>'}),
cmd('channelinfo',C,'Channel info',(m,a)=>{const c=chan(m,a[0])||m.channel;m.reply({embeds:[emb(c.name,`ID: ${c.id}\nType: ${c.type}\nCreated: ${T(c.createdTimestamp)}`)]})}),
cmd('membercount',C,'Member count',m=>m.reply(`👥 ${m.guild.memberCount}`),{aliases:['mc']}),
cmd('botinfo',C,'Bot info',m=>m.reply({embeds:[emb('🤖 Bot',`Servers: ${m.client.guilds.cache.size}\nCommands: ${m.client.commands.size}\ndiscord.js: v${version}\nNode: ${process.version}\nRAM: ${(process.memoryUsage().rss/1048576).toFixed(0)}MB`)]})),
cmd('invite',C,'Bot invite link',m=>m.reply(`https://discord.com/oauth2/authorize?client_id=${m.client.user.id}&scope=bot&permissions=8`)),
cmd('servericon',C,'Server icon',m=>m.reply(m.guild.iconURL({size:1024})||'No icon')),
cmd('say',C,'Bot says text',async(m,a)=>{await m.delete().catch(()=>{});m.channel.send({content:a.join(' '),allowedMentions:{parse:[]}})},{perm:'ManageMessages',args:1,usage:'<text>'}),
cmd('embed',C,'Make embed: title | text',async(m,a)=>{const [t,...d]=a.join(' ').split('|');await m.delete().catch(()=>{});m.channel.send({embeds:[emb(t.trim(),d.join('|').trim()||'\u200b')]})},{perm:'ManageMessages',args:1,usage:'<title> | <text>'}),
cmd('poll',C,'Poll: q | opt1 | opt2',async(m,a)=>{const [q,...o]=a.join(' ').split('|').map(x=>x.trim());const E=['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣'];const s=await m.channel.send({embeds:[emb('📊 '+q,o.length?o.map((x,i)=>`${E[i]} ${x}`).join('\n'):'👍 / 👎')]});if(o.length)for(let i=0;i<Math.min(o.length,9);i++)await s.react(E[i]);else{await s.react('👍');await s.react('👎')}},{args:1,usage:'<q> | <opt1> | <opt2>'}),
cmd('calc',C,'Calculator',(m,a)=>{const e=a.join(' ').replace(/\^/g,'**');if(!/^[\d+\-*/().%\s*]+$/.test(e))throw new Error('Invalid expression');m.reply(`🧮 ${Function(`return(${e})`)()}`)},{args:1,aliases:['math'],usage:'<expr>'}),
cmd('timestamp',C,'Current unix time',m=>m.reply(`\`${Math.floor(Date.now()/1e3)}\` <t:${Math.floor(Date.now()/1e3)}:F>`)),
cmd('snowflake',C,'Decode snowflake',(m,a)=>m.reply(`Created: <t:${Math.floor(Number((BigInt(a[0])>>22n)+1420070400000n)/1e3)}:F>`),{args:1}),
cmd('emojis',C,'List server emojis',m=>m.reply(m.guild.emojis.cache.map(e=>e.toString()).join(' ').slice(0,1900)||'None')),
cmd('roles',C,'List roles',m=>m.reply(m.guild.roles.cache.filter(r=>r.id!==m.guild.id).map(r=>r.name).join(', ').slice(0,1900))),
cmd('stealemoji',C,'Add emoji from another server',async(m,a)=>{const x=a[0].match(/<a?:(\w+):(\d+)>/);if(!x)throw new Error('Send a custom emoji');const e=await m.guild.emojis.create({attachment:`https://cdn.discordapp.com/emojis/${x[2]}.${a[0].startsWith('<a')?'gif':'png'}`,name:x[1]});m.reply(`✅ ${e}`)},{perm:'ManageGuildExpressions',args:1,usage:'<emoji>'}),
cmd('bots',C,'List bots',m=>m.reply(m.guild.members.cache.filter(x=>x.user.bot).map(x=>x.user.tag).join('\n')||'None')),
cmd('boosters',C,'List boosters',m=>m.reply(m.guild.members.cache.filter(x=>x.premiumSince).map(x=>x.user.tag).join('\n')||'None')),
cmd('perms',C,'Your permissions',async m=>{const t=await tgt(m);m.reply('```'+t.permissions.toArray().join(', ')+'```')}),
cmd('id',C,'Get IDs',async m=>{const t=await tgt(m);m.reply(`User: ${t.id}\nChannel: ${m.channel.id}\nServer: ${m.guild.id}`)}),
cmd('oldest',C,'Oldest accounts',async m=>{const x=(await m.guild.members.fetch()).sort((a,b)=>a.user.createdTimestamp-b.user.createdTimestamp).first(5);m.reply(x.map(y=>`${y.user.tag} ${T(y.user.createdTimestamp)}`).join('\n'))}),
cmd('joinedat',C,'When you joined',async m=>{const t=await tgt(m);m.reply(`📅 <t:${Math.floor(t.joinedTimestamp/1e3)}:F>`)}),
cmd('firstmsg',C,'First message in channel',async m=>{const x=(await m.channel.messages.fetch({after:'0',limit:1})).first();m.reply(x?x.url:'None')}),
cmd('stats',C,'Server stats',m=>m.reply(`Humans: ${m.guild.members.cache.filter(x=>!x.user.bot).size} | Bots: ${m.guild.members.cache.filter(x=>x.user.bot).size} | Text: ${m.guild.channels.cache.filter(c=>c.isTextBased()).size}`)),
];
