const {cmd,emb,member,id,dur,role,chan,del}=require('../util');const db=require('../db');
const {endGiveaway}=require('../systems');
const C='Systems',G=m=>m.guild.id;
const setCh=(n,key,d)=>cmd(n,C,d,(m,a)=>{const c=chan(m,a[0])||m.channel;db.set(`${key}:${G(m)}`,c.id);m.reply(`✅ ${d}: ${c}`)},{perm:'ManageGuild',usage:'[#channel]'});
const tog=(n,key,d)=>cmd(n,C,d,m=>{const k=`${key}:${G(m)}`;db.set(k,!db.get(k,false));m.reply(`${d}: **${db.get(k)?'ON':'OFF'}**`)},{perm:'ManageGuild'});
const text=(n,key,d)=>cmd(n,C,d+' ({user} {name} {server} {count})',(m,a)=>{db.set(`${key}:${G(m)}`,a.join(' '));m.reply('✅ Saved')},{perm:'ManageGuild',args:1,usage:'<text>'});
module.exports=[
cmd('prefix',C,'Change prefix',(m,a)=>{db.set(`prefix:${G(m)}`,a[0]);m.reply(`✅ Prefix: \`${a[0]}\``)},{perm:'ManageGuild',args:1}),
setCh('setwelcome','welcome','Welcome channel'),setCh('setleave','leave','Leave channel'),setCh('setlog','logch','Log channel'),
setCh('setsuggest','suggestch','Suggestions channel'),setCh('setstarboard','starch','Starboard channel'),setCh('setbdaychannel','bdaych','Birthday channel'),
text('welcomemsg','welcomemsg','Welcome message'),text('leavemsg','leavemsg','Leave message'),
cmd('setautorole',C,'Role given on join',(m,a)=>{const r=role(m,a[0]);if(!r)throw new Error('Role not found');db.set(`autorole:${G(m)}`,r.id);m.reply('✅ Saved')},{perm:'ManageGuild',args:1,usage:'<role>'}),
tog('antilink','am:link','Anti-link'),tog('antispam','am:spam','Anti-spam'),tog('anticaps','am:caps','Anti-caps'),tog('antimention','am:mention','Anti mass-mention'),
cmd('addbadword',C,'Add banned word',(m,a)=>{const k=`badwords:${G(m)}`;db.set(k,[...db.get(k,[]),a[0].toLowerCase()]);m.reply('✅ Added');m.delete().catch(()=>{})},{perm:'ManageGuild',args:1}),
cmd('removebadword',C,'Remove banned word',(m,a)=>{const k=`badwords:${G(m)}`;db.set(k,db.get(k,[]).filter(x=>x!==a[0].toLowerCase()));m.reply('✅ Removed')},{perm:'ManageGuild',args:1}),
cmd('badwords',C,'Banned words count',m=>m.reply(`${db.get(`badwords:${G(m)}`,[]).length} words`),{perm:'ManageGuild'}),
cmd('suggest',C,'Make a suggestion',async(m,a)=>{const c=m.guild.channels.cache.get(db.get(`suggestch:${G(m)}`));if(!c)throw new Error('Suggestion channel not set');const s=await c.send({embeds:[emb('💡 Suggestion',a.join(' ')).setFooter({text:m.author.tag})]});await s.react('👍');await s.react('👎');m.react('✅')},{args:1,usage:'<text>'}),
cmd('reactionrole',C,'Reaction role: <msgId> <emoji> <role>',async(m,a)=>{const r=role(m,a[2]);if(!r)throw new Error('Role not found');const msg=await m.channel.messages.fetch(a[0]);await msg.react(a[1]);db.set(`rr:${G(m)}:${a[0]}:${a[1].replace(/\D/g,'')||a[1]}`,r.id);m.reply('✅ Created')},{perm:'ManageRoles',args:3}),
cmd('rrremove',C,'Remove reaction role',(m,a)=>{db.del(`rr:${G(m)}:${a[0]}:${a[1].replace(/\D/g,'')||a[1]}`);m.reply('✅ Removed')},{perm:'ManageRoles',args:2}),
cmd('setcounting',C,'Counting channel',(m,a)=>{const c=chan(m,a[0])||m.channel;db.set(`count:${G(m)}`,{ch:c.id,n:0,last:null});m.reply(`🔢 Counting in ${c}. Start at 1!`)},{perm:'ManageGuild'}),
cmd('setticketcategory',C,'Ticket category ID',(m,a)=>{db.set(`ticketcat:${G(m)}`,a[0]);m.reply('✅')},{perm:'ManageGuild',args:1}),
cmd('ticket',C,'Open a ticket',async(m,a)=>{const c=await m.guild.channels.create({name:`ticket-${m.author.username}`.slice(0,90),parent:db.get(`ticketcat:${G(m)}`)||null,topic:m.author.id,permissionOverwrites:[{id:m.guild.id,deny:['ViewChannel']},{id:m.author.id,allow:['ViewChannel','SendMessages']}]});c.send(`🎫 ${m.author}, support will be with you soon.\nReason: ${a.join(' ')||'—'}\nClose with \`closeticket\`.`);m.reply(`✅ ${c}`)}),
cmd('closeticket',C,'Close ticket',async m=>{if(!m.channel.name.startsWith('ticket-'))throw new Error('Not a ticket');if(m.channel.topic!==m.author.id&&!m.member.permissions.has('ManageChannels'))throw new Error('Not allowed');await m.reply('🔒 Closing in 5s...');setTimeout(()=>m.channel.delete().catch(()=>{}),5000)}),
cmd('ticketadd',C,'Add user to ticket',async(m,a)=>{await m.channel.permissionOverwrites.edit(id(a[0]),{ViewChannel:true,SendMessages:true});m.reply('✅ Added')},{perm:'ManageChannels',args:1}),
cmd('ticketremove',C,'Remove user from ticket',async(m,a)=>{await m.channel.permissionOverwrites.delete(id(a[0]));m.reply('✅ Removed')},{perm:'ManageChannels',args:1}),
cmd('gstart',C,'Start giveaway',async(m,a)=>{const ms=dur(a[0]),w=parseInt(a[1]),prize=a.slice(2).join(' ');if(!ms||!w||!prize)throw new Error('Usage: gstart 1h 1 Prize');const s=await m.channel.send({content:'🎉 **GIVEAWAY** 🎉',embeds:[emb(prize,`React with 🎉 to enter!\nWinners: ${w}\nEnds: <t:${Math.floor((Date.now()+ms)/1e3)}:R>`)]});await s.react('🎉');db.push('giveaways',{g:G(m),ch:m.channel.id,msg:s.id,end:Date.now()+ms,w,prize});m.delete().catch(()=>{})},{perm:'ManageGuild',args:3,usage:'<1h> <winners> <prize>'}),
cmd('gend',C,'End giveaway now',async(m,a)=>{const l=db.get('giveaways',[]),x=l.find(g=>g.msg===a[0]);if(!x)throw new Error('Not found');db.set('giveaways',l.filter(g=>g!==x));endGiveaway(m.client,x)},{perm:'ManageGuild',args:1,usage:'<msgId>'}),
cmd('greroll',C,'Reroll winner',async(m,a)=>{const msg=await m.channel.messages.fetch(a[0]);const us=(await msg.reactions.cache.get('🎉').users.fetch()).filter(u=>!u.bot);if(!us.size)throw new Error('No entries');m.channel.send(`🎉 New winner: ${us.random()}`)},{perm:'ManageGuild',args:1,usage:'<msgId>'}),
cmd('gcancel',C,'Cancel giveaway',(m,a)=>{db.set('giveaways',db.get('giveaways',[]).filter(g=>g.msg!==a[0]));m.reply('🛑 Cancelled')},{perm:'ManageGuild',args:1}),
cmd('addcmd',C,'Add custom command',(m,a)=>{db.set(`cc:${G(m)}:${a[0].toLowerCase()}`,a.slice(1).join(' '));m.reply('✅ Added')},{perm:'ManageGuild',args:2,usage:'<name> <reply>'}),
cmd('delcmd',C,'Delete custom command',(m,a)=>{db.del(`cc:${G(m)}:${a[0].toLowerCase()}`);m.reply('✅ Deleted')},{perm:'ManageGuild',args:1}),
cmd('cmds',C,'List custom commands',m=>m.reply(db.all(`cc:${G(m)}:`).map(([k])=>`\`${k.split(':')[2]}\``).join(' ')||'None')),
cmd('afk',C,'Set AFK',(m,a)=>{db.set(`afk:${G(m)}:${m.author.id}`,a.join(' ')||'AFK');m.reply('💤 You are now AFK')}),
cmd('remind',C,'Reminder',(m,a)=>{const ms=dur(a[0]);if(!ms)throw new Error('Usage: remind 10m text');db.push('reminders',{u:m.author.id,ch:m.channel.id,at:Date.now()+ms,text:a.slice(1).join(' ')});m.reply('⏰ Okay!')},{args:2,usage:'<10m> <text>'}),
cmd('setbirthday',C,'Set birthday MM-DD',(m,a)=>{if(!/^\d\d-\d\d$/.test(a[0]))throw new Error('Format: 07-25');db.set(`bday:${G(m)}:${m.author.id}`,a[0]);m.reply('🎂 Saved')},{args:1}),
cmd('birthdays',C,'List birthdays',m=>m.reply(db.all(`bday:${G(m)}:`).map(([k,v])=>`<@${k.split(':')[2]}> — ${v}`).join('\n')||'None')),
cmd('settings',C,'Show server settings',m=>{const g=G(m);const f=k=>db.get(`${k}:${g}`)?'✅':'❌';m.reply({embeds:[emb('⚙️ Settings',`Welcome: ${f('welcome')}\nLeave: ${f('leave')}\nLogs: ${f('logch')}\nAutorole: ${f('autorole')}\nAnti-link: ${f('am:link')}\nAnti-spam: ${f('am:spam')}\nCounting: ${f('count')}\nStarboard: ${f('starch')}`)]})},{perm:'ManageGuild'}),
cmd('testwelcome',C,'Test welcome message',(m)=>m.client.emit('guildMemberAdd',m.member),{perm:'ManageGuild'}),
];
