const {cmd,emb,pick,rand,member,id}=require('../util');const db=require('../db');
const C='Economy',CUR='🪙';
const acc=(m,uid=m.author.id)=>{const k=`eco:${m.guild.id}:${uid}`;const o=db.get(k,{w:0,b:0,inv:{}});return{o,save:()=>db.set(k,o)}};
const cd=(m,n,ms)=>{const k=`cd:${n}:${m.guild.id}:${m.author.id}`,l=db.get(k,0),left=l+ms-Date.now();if(left>0)throw new Error(`Cooldown: ${Math.ceil(left/1000)}s`);db.set(k,Date.now())};
const amt=(s,max)=>s==='all'?max:parseInt(s);
const earn=([n,ms,lo,hi,msg,fail])=>cmd(n,C,`Earn coins (${n})`,m=>{cd(m,n,ms);const a=acc(m);const g=rand(lo,hi);if(fail&&Math.random()<fail){const l=Math.min(a.o.w,rand(lo,hi)/2|0);a.o.w-=l;a.save();return m.reply(`🚔 You failed and lost ${l} ${CUR}`)}a.o.w+=g;a.save();m.reply(`${msg} **${g}** ${CUR}`)});
const EARN=[['daily',864e5,500,500,'📅 Daily reward:'],['weekly',6048e5,3000,3000,'📆 Weekly reward:'],['monthly',2592e6,10000,10000,'🗓️ Monthly reward:'],['work',36e5,100,300,'💼 You worked and earned'],['beg',6e4,5,60,'🙏 Someone gave you'],['crime',18e5,200,600,'🕶️ Crime paid',.4],['fish',9e5,40,150,'🎣 You caught fish worth'],['hunt',9e5,50,180,'🏹 You hunted and got'],['mine',12e5,60,220,'⛏️ You mined'],['dig',6e5,30,120,'🕳️ You dug up'],['farm',18e5,80,250,'🌾 Harvest worth'],['chop',6e5,30,100,'🪓 Wood sold for'],['stream',36e5,120,320,'📺 Stream donations:'],['delivery',9e5,50,160,'📦 Delivery tips:']];
const SHOP={laptop:[1500,'💻'],phone:[800,'📱'],car:[20000,'🚗'],house:[100000,'🏠'],ring:[5000,'💍'],rod:[600,'🎣'],pickaxe:[900,'⛏️'],crown:[500000,'👑']};
const gamble=(n,d,f)=>cmd(n,C,d,m=>{const a=acc(m);const b=amt(m.content.split(/\s+/)[1],a.o.w);if(!(b>0)||b>a.o.w)throw new Error('Invalid bet');const r=f(b,m);a.o.w+=r.d;a.save();m.reply(`${r.t} (${r.d>=0?'+':''}${r.d} ${CUR})`)},{args:1,usage:'<amount|all>'});
module.exports=[...EARN.map(earn),
cmd('balance',C,'Check balance',async m=>{const t=(await member(m,m.content.split(/\s+/)[1]))||m.member;const a=acc(m,t.id);m.reply({embeds:[emb(`${t.user.username}'s balance`,`Wallet: **${a.o.w}** ${CUR}\nBank: **${a.o.b}** ${CUR}`)]})},{aliases:['bal','money']}),
cmd('deposit',C,'Deposit to bank',(m,a)=>{const x=acc(m);const n=amt(a[0],x.o.w);if(!(n>0)||n>x.o.w)throw new Error('Invalid');x.o.w-=n;x.o.b+=n;x.save();m.reply(`🏦 Deposited ${n}`)},{args:1,aliases:['dep']}),
cmd('withdraw',C,'Withdraw from bank',(m,a)=>{const x=acc(m);const n=amt(a[0],x.o.b);if(!(n>0)||n>x.o.b)throw new Error('Invalid');x.o.b-=n;x.o.w+=n;x.save();m.reply(`💵 Withdrew ${n}`)},{args:1,aliases:['with']}),
cmd('pay',C,'Pay a user',async(m,a)=>{const t=await member(m,a[0]);const n=parseInt(a[1]);const x=acc(m);if(!t||!(n>0)||n>x.o.w)throw new Error('Invalid');const y=acc(m,t.id);x.o.w-=n;y.o.w+=n;x.save();y.save();m.reply(`✅ Paid ${n} ${CUR} to ${t}`)},{args:2,usage:'<user> <amount>',aliases:['give','transfer']}),
cmd('rob',C,'Rob a user',async(m,a)=>{cd(m,'rob',36e5);const t=await member(m,a[0]);if(!t||t.id===m.author.id)throw new Error('Invalid target');const v=acc(m,t.id),x=acc(m);if(v.o.w<200)throw new Error('Target is too poor');if(Math.random()<.5){const s=rand(50,v.o.w/2|0);v.o.w-=s;x.o.w+=s;v.save();x.save();m.reply(`🦹 Stole ${s} ${CUR}`)}else{const f=Math.min(x.o.w,200);x.o.w-=f;x.save();m.reply(`🚔 Caught! Fined ${f} ${CUR}`)}},{args:1,usage:'<user>'}),
cmd('shop',C,'View shop',m=>m.reply({embeds:[emb('🛒 Shop',Object.entries(SHOP).map(([k,[p,e]])=>`${e} **${k}** — ${p} ${CUR}`).join('\n'))]})),
cmd('buy',C,'Buy item',(m,a)=>{const it=SHOP[a[0]?.toLowerCase()];if(!it)throw new Error('Item not found');const x=acc(m);if(x.o.w<it[0])throw new Error('Not enough coins');x.o.w-=it[0];x.o.inv[a[0].toLowerCase()]=(x.o.inv[a[0].toLowerCase()]||0)+1;x.save();m.reply(`${it[1]} Bought **${a[0]}**`)},{args:1}),
cmd('sell',C,'Sell item (50%)',(m,a)=>{const k=a[0]?.toLowerCase(),x=acc(m);if(!x.o.inv[k])throw new Error("You don't own it");x.o.inv[k]--;x.o.w+=SHOP[k][0]/2;x.save();m.reply(`💰 Sold for ${SHOP[k][0]/2}`)},{args:1}),
cmd('inventory',C,'Your items',m=>{const x=acc(m);const e=Object.entries(x.o.inv).filter(([,n])=>n>0);m.reply(e.length?e.map(([k,n])=>`${SHOP[k]?.[1]||''} ${k} x${n}`).join('\n'):'Empty')},{aliases:['inv']}),
cmd('richest',C,'Richest users',m=>{const l=db.all(`eco:${m.guild.id}:`).map(([k,v])=>[k.split(':')[2],v.w+v.b]).sort((a,b)=>b[1]-a[1]).slice(0,10);m.reply({embeds:[emb('💰 Richest',l.map((x,i)=>`${i+1}. <@${x[0]}> — ${x[1]}`).join('\n')||'Empty')]})},{aliases:['ecotop','rich']}),
gamble('slots','Slot machine',(b)=>{const e=['🍒','🍋','🍇','💎','7️⃣'];const r=[pick(e),pick(e),pick(e)];const w=r[0]===r[1]&&r[1]===r[2]?b*5:r[0]===r[1]||r[1]===r[2]?b:-b;return{t:r.join(' '),d:w}}),
gamble('coinbet','Bet on coin',b=>Math.random()<.5?{t:'🪙 Won!',d:b}:{t:'🪙 Lost',d:-b}),
gamble('gamble','Gamble 45% win',b=>Math.random()<.45?{t:'🎰 You won!',d:b}:{t:'🎰 You lost',d:-b}),
gamble('blackjack','Quick blackjack',b=>{const p=rand(14,23),d=rand(14,23);return p>21?{t:`Bust (${p})`,d:-b}:d>21||p>d?{t:`You ${p} vs ${d}: win!`,d:b}:p===d?{t:`Tie ${p}`,d:0}:{t:`You ${p} vs ${d}: lose`,d:-b}}),
gamble('roulette','Roulette red/black',(b,m)=>{const c=(m.content.split(/\s+/)[2]||'').toLowerCase();if(!['red','black'].includes(c))throw new Error('Pick red or black');const r=pick(['red','black','green']);return r===c?{t:`🎡 ${r}! Won`,d:b}:{t:`🎡 ${r}. Lost`,d:-b}}),
gamble('dicebet','Beat the dice (4+)',b=>{const r=rand(1,6);return r>=4?{t:`🎲 ${r} Won`,d:b}:{t:`🎲 ${r} Lost`,d:-b}}),
gamble('doubleornothing','50/50 double',b=>Math.random()<.5?{t:'💥 Doubled!',d:b}:{t:'💀 Lost it all',d:-b}),
cmd('heist',C,'Bank heist',m=>{cd(m,'heist',72e5);const x=acc(m);if(Math.random()<.3){const g=rand(1000,3000);x.o.w+=g;x.save();m.reply(`🏦 Heist success: +${g} ${CUR}`)}else{const l=Math.min(x.o.w,500);x.o.w-=l;x.save();m.reply(`🚨 Failed! -${l} ${CUR}`)}}),
cmd('addmoney',C,'Admin: add coins',async(m,a)=>{const t=await member(m,a[0]);const y=acc(m,t.id);y.o.w+=parseInt(a[1]);y.save();m.reply('✅')},{perm:'Administrator',args:2,usage:'<user> <amt>'}),
cmd('removemoney',C,'Admin: remove coins',async(m,a)=>{const t=await member(m,a[0]);const y=acc(m,t.id);y.o.w=Math.max(0,y.o.w-parseInt(a[1]));y.save();m.reply('✅')},{perm:'Administrator',args:2,usage:'<user> <amt>'}),
cmd('resetmoney',C,'Admin: reset user',async(m,a)=>{db.del(`eco:${m.guild.id}:${id(a[0])}`);m.reply('✅')},{perm:'Administrator',args:1}),
cmd('networth',C,'Net worth with items',m=>{const x=acc(m);const iv=Object.entries(x.o.inv).reduce((s,[k,n])=>s+(SHOP[k]?SHOP[k][0]*n:0),0);m.reply(`💎 ${x.o.w+x.o.b+iv} ${CUR}`)}),
];
