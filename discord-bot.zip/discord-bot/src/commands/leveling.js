const {cmd,emb,member,id,role}=require('../util');const db=require('../db');const {lvl}=require('../systems');
const C='Leveling';
const need=n=>100*n*n;
module.exports=[
cmd('rank',C,'Your level & XP',async m=>{const t=(await member(m,m.content.split(/\s+/)[1]))||m.member;const xp=db.get(`xp:${m.guild.id}:${t.id}`,0),l=lvl(xp);m.reply({embeds:[emb(`${t.user.username}'s rank`,`Level **${l}**\nXP: ${xp}/${need(l+1)}`)]})},{aliases:['level','xp']}),
cmd('levels',C,'XP leaderboard',m=>{const l=db.all(`xp:${m.guild.id}:`).map(([k,v])=>[k.split(':')[2],v]).sort((a,b)=>b[1]-a[1]).slice(0,10);m.reply({embeds:[emb('🏆 Top XP',l.map((x,i)=>`${i+1}. <@${x[0]}> — Lv ${lvl(x[1])} (${x[1]} xp)`).join('\n')||'Empty')]})},{aliases:['lb','top']}),
cmd('setxp',C,'Set user XP',async(m,a)=>{db.set(`xp:${m.guild.id}:${id(a[0])}`,parseInt(a[1])||0);m.reply('✅')},{perm:'Administrator',args:2,usage:'<user> <xp>'}),
cmd('addxp',C,'Add user XP',async(m,a)=>{db.add(`xp:${m.guild.id}:${id(a[0])}`,parseInt(a[1])||0);m.reply('✅')},{perm:'Administrator',args:2,usage:'<user> <xp>'}),
cmd('resetxp',C,'Reset user XP',async(m,a)=>{db.del(`xp:${m.guild.id}:${id(a[0])}`);m.reply('✅')},{perm:'Administrator',args:1,usage:'<user>'}),
cmd('levelrole',C,'Role reward at level',(m,a)=>{const r=role(m,a[1]);if(!r)throw new Error('Role not found');const o=db.get(`lvlroles:${m.guild.id}`,{});o[parseInt(a[0])]=r.id;db.set(`lvlroles:${m.guild.id}`,o);m.reply('✅ Saved')},{perm:'ManageRoles',args:2,usage:'<level> <role>'}),
cmd('dellevelrole',C,'Remove level reward',(m,a)=>{const o=db.get(`lvlroles:${m.guild.id}`,{});delete o[parseInt(a[0])];db.set(`lvlroles:${m.guild.id}`,o);m.reply('✅ Removed')},{perm:'ManageRoles',args:1,usage:'<level>'}),
cmd('levelroles',C,'List level rewards',m=>{const o=db.get(`lvlroles:${m.guild.id}`,{});m.reply(Object.entries(o).map(([l,r])=>`Lv ${l} → <@&${r}>`).join('\n')||'None')}),
cmd('toggleleveling',C,'Enable/disable leveling',m=>{const k=`lvloff:${m.guild.id}`;db.set(k,!db.get(k,false));m.reply(`Leveling ${db.get(k)?'OFF':'ON'}`)},{perm:'ManageGuild'}),
cmd('resetall',C,'Reset all XP',m=>{db.all(`xp:${m.guild.id}:`).forEach(([k])=>db.del(k));m.reply('🧹 Done')},{perm:'Administrator'}),
];
