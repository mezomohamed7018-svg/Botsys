const {cmd}=require('../util');const C='Text';
const T=(n,d,f)=>cmd(n,C,d,(m,a)=>m.reply({content:String(f(a.join(' '))).slice(0,1900)||'\u200b',allowedMentions:{parse:[]}}),{args:1,usage:'<text>'});
const map={a:'ａ'};const wide=s=>s.replace(/[!-~]/g,c=>String.fromCharCode(c.charCodeAt(0)+0xFEE0));
const flipM={a:'ɐ',b:'q',c:'ɔ',d:'p',e:'ǝ',f:'ɟ',g:'ƃ',h:'ɥ',i:'ᴉ',j:'ɾ',k:'ʞ',l:'l',m:'ɯ',n:'u',o:'o',p:'d',q:'b',r:'ɹ',s:'s',t:'ʇ',u:'n',v:'ʌ',w:'ʍ',x:'x',y:'ʎ',z:'z'};
module.exports=[
T('reverse','Reverse text',s=>[...s].reverse().join('')),
T('upper','UPPERCASE',s=>s.toUpperCase()),T('lower','lowercase',s=>s.toLowerCase()),
T('title','Title Case',s=>s.replace(/\w\S*/g,w=>w[0].toUpperCase()+w.slice(1).toLowerCase())),
T('clap','Add 👏',s=>s.split(/\s+/).join(' 👏 ')),
T('owo','OwO-ify',s=>s.replace(/[rl]/g,'w').replace(/[RL]/g,'W')+' uwu'),
T('vaporwave','Ｖａｐｏｒ',wide),
T('mock','mOcKiNg',s=>[...s].map((c,i)=>i%2?c.toUpperCase():c.toLowerCase()).join('')),
T('emojify','Letters to emoji',s=>[...s.toLowerCase()].map(c=>/[a-z]/.test(c)?`:regional_indicator_${c}:`:c).join(' ')),
T('spoiler','Spoiler text',s=>`||${s}||`),
T('fliptext','Flip text',s=>[...s.toLowerCase()].reverse().map(c=>flipM[c]||c).join('')),
T('bin','Text to binary',s=>[...s].map(c=>c.charCodeAt(0).toString(2).padStart(8,'0')).join(' ')),
T('unbin','Binary to text',s=>s.split(' ').map(b=>String.fromCharCode(parseInt(b,2))).join('')),
T('b64','Base64 encode',s=>Buffer.from(s).toString('base64')),
T('unb64','Base64 decode',s=>Buffer.from(s,'base64').toString()),
T('hex','Text to hex',s=>Buffer.from(s).toString('hex')),
T('unhex','Hex to text',s=>Buffer.from(s.replace(/\s/g,''),'hex').toString()),
T('urlenc','URL encode',encodeURIComponent),T('urldec','URL decode',decodeURIComponent),
T('charcount','Count characters',s=>`${s.length} characters`),
T('wordcount','Count words',s=>`${s.trim().split(/\s+/).length} words`),
T('snake','snake_case',s=>s.trim().toLowerCase().replace(/\s+/g,'_')),
T('camel','camelCase',s=>s.trim().toLowerCase().replace(/\s+(.)/g,(_,c)=>c.toUpperCase())),
T('kebab','kebab-case',s=>s.trim().toLowerCase().replace(/\s+/g,'-')),
T('morse','Text to morse',s=>{const M={a:'.-',b:'-...',c:'-.-.',d:'-..',e:'.',f:'..-.',g:'--.',h:'....',i:'..',j:'.---',k:'-.-',l:'.-..',m:'--',n:'-.',o:'---',p:'.--.',q:'--.-',r:'.-.',s:'...',t:'-',u:'..-',v:'...-',w:'.--',x:'-..-',y:'-.--',z:'--..',0:'-----',1:'.----',2:'..---',3:'...--',4:'....-',5:'.....',6:'-....',7:'--...',8:'---..',9:'----.'};return [...s.toLowerCase()].map(c=>M[c]||(c===' '?'/':'')).join(' ')}),
T('shuffle','Shuffle letters',s=>[...s].sort(()=>Math.random()-.5).join('')),
T('palindrome','Is it a palindrome?',s=>{const x=s.toLowerCase().replace(/[^a-z0-9]/g,'');return x===[...x].reverse().join('')?'✅ Yes':'❌ No'}),
T('repeat','Repeat 3x',s=>`${s} ${s} ${s}`),
T('sarcasm','Sarcastic',s=>`Oh wow, "${s}". Truly groundbreaking. 🙄`),
];
