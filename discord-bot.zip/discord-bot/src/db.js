const fs=require('fs'),F='./data.json';let d={};try{d=JSON.parse(fs.readFileSync(F))}catch{}
let t;const save=()=>{clearTimeout(t);t=setTimeout(()=>fs.writeFileSync(F,JSON.stringify(d)),500)};
module.exports={get:(k,def)=>k in d?d[k]:def,set:(k,v)=>{d[k]=v;save();return v},add:(k,n)=>{d[k]=(d[k]||0)+n;save();return d[k]},push:(k,v)=>{(d[k]=d[k]||[]).push(v);save()},del:k=>{delete d[k];save()},all:p=>Object.entries(d).filter(([k])=>k.startsWith(p))};
