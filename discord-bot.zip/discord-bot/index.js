require('dotenv').config();
const {Client,GatewayIntentBits:I,Partials}=require('discord.js');
const fs=require('fs');
const client=new Client({intents:[I.Guilds,I.GuildMembers,I.GuildMessages,I.MessageContent,I.GuildVoiceStates,I.GuildMessageReactions,I.GuildModeration],partials:[Partials.Message,Partials.Channel,Partials.Reaction,Partials.User]});
client.commands=new Map();client.aliases=new Map();
for(const f of fs.readdirSync('./src/commands'))for(const c of require('./src/commands/'+f)){client.commands.set(c.name,c);(c.aliases||[]).forEach(a=>client.aliases.set(a,c.name))}
for(const f of fs.readdirSync('./src/events')){const e=require('./src/events/'+f);client.on(e.name,(...a)=>e.run(client,...a))}
process.on('unhandledRejection',e=>console.error(e));
console.log(`Loaded ${client.commands.size} commands`);
client.login(process.env.TOKEN);
